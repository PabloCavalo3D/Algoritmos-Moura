programa
{
    funcao inicio()
    {
        inteiro matriz[3][3]

        escreva("Preencha a matriz 3x3:\n")
        para (inteiro i = 0; i < 3; i++)
        {
            para (inteiro j = 0; j < 3; j++)
            {
                escreva("Elemento [", i, "][", j, "]: ")
                leia(matriz[i][j])
            }
        }

        escreva("\nDiagonal Principal:\n")
        para (inteiro i = 0; i < 3; i++)
        {
            escreva(matriz[i][i], " ")
        }
    }
}