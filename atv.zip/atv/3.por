programa
{
    funcao inicio()
    {
        cadeia nomes[3]
        real notas[3][2]
        real media

        escreva("=== BOLETIM ESCOLAR ===\n")
        para (inteiro i = 0; i < 3; i++)
        {
            escreva("\nAluno ", i+1, "\n")
            escreva("Nome: ")
            leia(nomes[i])
            escreva("Nota 1: ")
            leia(notas[i][0])
            escreva("Nota 2: ")
            leia(notas[i][1])
        }

        escreva("\n=== RESULTADOS ===\n")
        para (inteiro i = 0; i < 3; i++)
        {
            media = (notas[i][0] + notas[i][1]) / 2
            escreva(nomes[i], " - Media: ", media, "\n")
        }
    }
}