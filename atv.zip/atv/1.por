programa
{
    funcao inicio()
    {
        inteiro numeros[5]

        escreva("Digite 5 numeros inteiros:\n")
        para (inteiro i = 0; i < 5; i++)
        {
            escreva("Numero ", i+1, ": ")
            leia(numeros[i])
        }

        escreva("\nOrdem inversa:\n")
        para (inteiro i = 4; i >= 0; i--)
        {
            escreva(numeros[i], " ")
        }
    }
}