programa
{
    funcao inicio()
    {
        inteiro matriz[3][3]
        inteiro soma = 0

        escreva("Preencha a matriz 3x3:\n")
        para (inteiro i = 0; i < 3; i++)
        {
            para (inteiro j = 0; j < 3; j++)
            {
                escreva("Elemento [", i, "][", j, "]: ")
                leia(matriz[i][j])
                soma = soma + matriz[i][j]
            }
        }

        escreva("\nSoma de todos os elementos = ", soma)
    }
}
